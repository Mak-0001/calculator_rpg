extends AbilityScript;


static func main(source: Ability) -> int:
	var user: Entity = BattleMenager.nodes_in_battle[BattleMenager.turn_index];
	user.block += source.block_amount;
	BattleMenager.add_battle_log(source.ability_name + ": +" + str(source.block_amount));
	return ability_type.SPECIAL;
